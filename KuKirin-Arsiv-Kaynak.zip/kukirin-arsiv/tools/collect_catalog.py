import json,hashlib,re,subprocess,concurrent.futures,io,urllib.request
from pathlib import Path
from bs4 import BeautifulSoup
from PIL import Image
BASE=Path(__file__).resolve().parents[1]; assets=BASE/'android/app/src/main/assets'; research=BASE/'research'
def text(s):return BeautifulSoup(s or '', 'html.parser').get_text(' ',strip=True)
labels={'Motor':'Motor gücü','Motors':'Motor gücü','Top Speed':'Azami hız','Top speed':'Azami hız','Battery':'Batarya','Range':'Azami menzil','Tires':'Lastikler','Tyres':'Lastikler','Climbing Ability':'Tırmanma açısı','Climbing ability':'Tırmanma açısı','Climbing':'Tırmanma açısı','Max load':'Taşıma kapasitesi','Maximum load':'Taşıma kapasitesi','Load Capacity':'Taşıma kapasitesi','Brakes':'Frenler','Braking System':'Frenler','Suspension':'Süspansiyon','Display':'Ekran','Lighting':'Aydınlatma','Lights':'Aydınlatma','IP Rating':'Koruma sınıfı','IP rating':'Koruma sınıfı','Water resistance':'Koruma sınıfı','Waterproof level':'Koruma sınıfı','Charging Time':'Şarj süresi','Charging time':'Şarj süresi','Charging':'Şarj','Dimensions (Unfolded/Folded)':'Açık / katlı ölçüler','Size':'Ölçüler','Size (Unfolded / Folded)':'Açık / katlı ölçüler','Weight':'Ağırlık','Net weight':'Ağırlık','Seat':'Koltuk','Speed modes':'Hız modları','Product Model':'Model','Product color':'Renk','product net weight':'Ağırlık','product gross weight':'Paket ağırlığı','Handle width':'Gidon genişliği','Pedal width':'Platform genişliği','Expand dimension':'Açık ölçüler','Folding dimension':'Katlı ölçüler','Packing size':'Paket ölçüleri','Battery Type':'Batarya tipi','Battery Energy':'Batarya enerjisi','Voltage/Capacitance':'Batarya','Cruising mileage':'Azami menzil','Type of motor':'Motor tipi','Rated power':'Motor gücü','Peak power':'Tepe motor gücü','Maximum load':'Taşıma kapasitesi','Climbing angle':'Tırmanma açısı','Gear/speed':'Hız modları','Top speed':'Azami hız','Tyre type':'Lastikler','Braking mode':'Frenler','Braking distance':'Fren mesafesi','damping system':'Süspansiyon','Instrument display':'Ekran','Car light system':'Aydınlatma','Waterproof grade':'Koruma sınıfı','Applicable Age':'Önerilen yaş','Applicable height':'Önerilen boy','Applicable Scenarios':'Kullanım alanı'}
translations={'brushless':'fırçasız','motor':'motor','lithium-ion':'lityum iyon','lithium battery':'lityum batarya','off-road':'arazi','pneumatic':'havalı','tubeless':'iç lastiksiz','honeycomb':'petek dolgu','puncture-resistant':'patlamaya dayanıklı','front & rear':'ön ve arka','front and rear':'ön ve arka','Front and rear':'Ön ve arka','front + rear':'ön + arka','dual':'çift','Dual':'Çift','disc brakes':'disk fren','disc brake':'disk fren','hydraulic':'hidrolik','spring':'yaylı','suspension':'süspansiyon','hours':'saat','hour':'saat','up to':'en fazla','Up to':'En fazla','under ideal conditions':'ideal koşullarda','Approximately':'Yaklaşık','approximately':'yaklaşık','approx.':'yaklaşık','Black':'Siyah','Yes':'Var','detachable':'çıkarılabilir','removable':'çıkarılabilir','turn signals':'sinyaller','headlight':'ön far','taillight':'arka far','mechanical foot brake':'mekanik ayak freni','electronic brake':'elektronik fren','mechanical rear brake':'mekanik arka fren','electronic braking':'elektronik fren','integrated hub motor':'göbek motor','Integrated hub motor':'Göbek motor','Electronic front and rear disc brakes':'Ön ve arka elektronik disk fren','inflatable':'havalı','√':'Var','First gear':'1. mod','Second gear':'2. mod','Third gear':'3. mod','to 50 years old':'–50 yaş','to 60 years old':'–60 yaş','to 65 years old':'–65 yaş','nominal':'nominal','peak':'tepe','total':'toplam','capacity':'kapasite'}
def tr(s):
 for a,b in translations.items():s=s.replace(a,b)
 return s
# Values below are transcribed from the product pages saved in research/.
core={
'G2 2026':('800 W','45 km/h','55 km','48 V 15 Ah'),'G2 Master 2026':('2 × 1000 W','60 km/h','70 km','52 V 20,8 Ah'),'G2 Pro 2026':('600 W','45 km/h','55 km','48 V 15 Ah'),'G4 2026':('2000 W','70 km/h','75 km','60 V 20 Ah'),'G2 Max':('1000 W','55 km/h','70–80 km','48 V 20–20,8 Ah'),'G3':('1200 W','50 km/h','70 km',None),'G3 Pro':('2 × 1200 W','65 km/h','80 km','52 V 23,2–23,4 Ah'),'G4 Max':('2 × 1600 W','86 km/h','95 km','60 V 35,2 Ah'),'G2 Ultra':('2 × 800 W','50 km/h','55–60 km','48 V 18 Ah'),'G4 Ultra':('2 × 1200 W','70 km/h','80 km','60 V 20 Ah'),'T4':('1500 W','65 km/h','80 km','52 V 22,5 Ah'),'T3':('800 W','45 km/h','58 km','48 V 15,6 Ah'),'A1':('800 W','45 km/h','45 km',None),'M4 Max':('800 W','45 km/h','64 km','48 V 18,2 Ah'),'S1 Max':('350 W','25 km/h','39 km','36 V 10,4 Ah'),'M4 Pro':('500 W','45 km/h','60–70 km','48 V 18 Ah'),'S1 Pro':('350 W','30 km/h','30 km','36 V 7,5 Ah'),'S3 Pro':('350 W','25 km/h','30 km','36 V 7,5 Ah'),'G2 Pro DGT':('500 W','25 km/h','65 km','48 V 15 Ah'),
'G2':('800 W','45 km/h','55 km','48 V 15 Ah'),'G2 Master':('2 × 1000 W','60 km/h','70 km','52 V 20,8 Ah'),'G4':('2000 W','70 km/h','70 km','60 V 20 Ah'),'G2 Pro':('600 W','45 km/h','58 km','48 V 15,6 Ah'),'G2 Pro ABE':('500 W','20 km/h','65 km','48 V 15,6 Ah'),'G2 Pro VMP':('500 W','25 km/h','65 km','48 V 15,6 Ah'),'M4':('500 W','45 km/h','40 km','48 V 12,5 Ah'),'M5 Pro':('1200 W','52 km/h','70 km','48 V 20 Ah')}
models=[]
def add(name,brand,url,imgs,specs,variant='Standart',note=''):
 series=re.match(r'[A-Z]+',name);series=series.group() if series else 'Diğer'
 mid=re.sub('[^a-z0-9]+','-',(brand+' '+name+' '+variant).lower()).strip('-')+'-'+hashlib.sha256(url.encode()).hexdigest()[:6]
 models.append(dict(id=mid,name=name,brand=brand,series=series,variant=variant,source=url,checked='13 Ekim 2026',specs=specs,imageSources=imgs[:3],images=[],note=note))
for site in ['kukirinofficial.com','www.kugookirineu.com']:
 for p in json.load(open(research/(site+'.json')))['products']:
  title=p['title']
  if not re.match(r'(KuKirin|KUKIRIN) [A-Z][0-9].*Electric Scooter',title) or any(w in title for w in ['Bundle','x2',' + ']):continue
  name=re.sub(r'^(KuKirin|KUKIRIN) ','',title).split(' Electric Scooter')[0]
  name=name.replace('Electric Scooter','').strip()
  if 'dgt-certified' in p['handle']:name='G2 Pro DGT'
  if 'abe-version' in p['handle']:name='G2 Pro ABE'
  if '-vmp' in p['handle']:name='G2 Pro VMP'
  if name=='G4' and site.endswith('kirineu.com'):pass
  # Keep the shop revision distinct only where a named 2026 revision exists.
  if any(m['name']==name and m['brand']=='KuKirin' for m in models):continue
  body=BeautifulSoup(p['body_html'] or '', 'html.parser');specs={}
  raw=body.get_text('\n',strip=True)
  for k in sorted(labels,key=len,reverse=True):
   match=re.search(r'(?:^|\n)'+re.escape(k)+r'\s*:?\s*\n?\s*:\s*([^\n]+)',raw)
   if not match:match=re.search(r'(?:^|\n)'+re.escape(k)+r'\s*:\s*([^\n]+)',raw)
   if match:specs[labels[k]]=tr(match.group(1))
  if name in core:
   for key,val in zip(['Motor gücü','Azami hız','Azami menzil','Batarya'],core[name]):
    if val:specs[key]=val
  if name=='M4':specs['Lastikler']='10 inç';specs['Koltuk']='Çıkarılabilir'
  # Optional specification tables from store support pages.
  tags=p.get('tags',[])
  slug=next((t.split(':',1)[1] for t in tags if t.startswith('__specifications:')),None)
  if slug:
   specfile=research/('spec-'+slug+'.html')
   if not specfile.exists():subprocess.run(['curl','-sL','--max-time','20','https://'+site+'/pages/'+slug,'-o',str(specfile)])
   if specfile.exists():
    support=BeautifulSoup(specfile.read_text(),'html.parser')
    for row in support.select('tr'):
     cells=[c.get_text(' ',strip=True) for c in row.select('td,th')]
     if len(cells)==2:
      key=cells[0].rstrip(':').strip()
      if key in labels and labels[key] not in specs:specs[labels[key]]=tr(cells[1])
  note='Değerler kaynakta belirtilen sürüme aittir. Model yılı ve satış bölgesine göre özellikler değişebilir.'
  if name in ['G4 Ultra','T4']:note+=' Kaynak sayfada ön sipariş olarak listeleniyor.'
  variant='2026 sürümü' if '2026' in name else ('Bölgesel sürüm' if any(x in name for x in ['ABE','VMP','DGT']) else 'Mağaza kaydı')
  add(name,'KuKirin','https://'+site+'/products/'+p['handle'],[i['src'] for i in p['images']],specs,variant,note)
# Manufacturer records retain their identity separately from KuKirin shop revisions.
for path in sorted(research.glob('legacy-*.html')):
 if path.name=='legacy-home.html' or path.name in ['legacy-15.html','legacy-19.html']:continue
 soup=BeautifulSoup(path.read_text(),'html.parser');tables=soup.select('table');specs={}
 for table in tables:
  for row in table.select('tr'):
   cells=[c.get_text(' ',strip=True) for c in row.select('td')]
   if len(cells)==2 and cells[0] in labels:specs[labels[cells[0]]]=tr(cells[1])
 name=specs.get('Model','').replace('М','M')
 if not name or not specs.get('Motor gücü') or name in ['V1','V2','V3','F1','F1 Pro','Note','C2 Pro','U1','U2','U3','U4','U5','U6','Galloping horse']:continue
 # The downloaded manufacturer's scooter tables are the archive source.
 images=[]
 for im in soup.select('img'):
  if im.get('alt','').replace('М','M')==name or im.get('title','').replace('М','M')==name:
   src=im.get('lazy') or im.get('src','')
   if src.startswith('https:') and src not in images:images.append(src)
 # Product hero images follow the menu and precede the parameter tables.
 if not images:
  for im in soup.select('img')[78:]:
   src=im.get('lazy') or im.get('src','')
   if src.startswith('https:') and not im.get('alt'):
    images.append(src);break
 add(name,'Kugoo Kirin','https://en.kugookirin.com/Products_details/'+path.name[7:],images,specs,'Üretici kaydı','Üretici kataloğundaki bölgesel model. Aynı isimli KuKirin mağaza sürümüyle teknik değerleri farklı olabilir.')
# Save and compress source photographs into the APK for offline use.
def download(task):
 m,i,url=task;target=assets/'images'/f"{m['id']}-{i}.webp"
 try:
  if not target.exists():
   fetch=url+('&' if '?' in url else '?')+'width=900' if 'shopify' in url else url
   req=urllib.request.Request(fetch,headers={'User-Agent':'Mozilla/5.0'})
   
   if 'thefastimg.com' in url:
    temp=research/(target.stem+'.tmp');subprocess.run(['curl_chrome150','-sL','--max-time','25',url,'-o',str(temp)]);data=temp.read_bytes();temp.unlink()
   else:data=urllib.request.urlopen(req,timeout=35).read()
   im=Image.open(io.BytesIO(data));im.thumbnail((1000,1000));im.save(target,'WEBP',quality=85)
  return m,i,'images/'+target.name
 except Exception as e:return m,i,None
jobs=[(m,i,u) for m in models for i,u in enumerate(m['imageSources'][:2])]
for m,i,path in concurrent.futures.ThreadPoolExecutor(max_workers=8).map(download,jobs):
 if path:m['images'].append(path)
for m in models:
 if not m['images']:print('MISSING PHOTO',m['brand'],m['name'])
models.sort(key=lambda m:(m['brand']!='KuKirin',m['series'],m['name']))
(assets/'catalog.js').write_text('window.CATALOG = '+json.dumps(models,ensure_ascii=False)+';\n')
(research/'catalog.json').write_text(json.dumps(models,ensure_ascii=False,indent=2))
print('CATALOG',len(models),'records',sum(bool(m['images']) for m in models),'with photos')
