#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TASK_SDK="${KUKIRIN_BUILD_TOOLS:-$HOME/.cache/kukirin-build}"
TASK_JDK="$(find "$TASK_SDK" -maxdepth 1 -type d -name 'jdk-*' | head -1)"
export JAVA_HOME="$TASK_JDK"
export PATH="$TASK_JDK/bin:$PATH"
TASK_BT="$TASK_SDK/android-15"
TASK_PLATFORM="$TASK_SDK/android-35/android.jar"
TASK_BUILD="$TASK_ROOT/android/build"
mkdir -p "$TASK_BUILD/classes" "$TASK_BUILD/dex" "$TASK_ROOT/outputs"
chmod +x "$TASK_BT/aapt2" "$TASK_BT/zipalign" "$TASK_BT/apksigner" "$TASK_BT/d8"
"$TASK_BT/aapt2" compile --dir "$TASK_ROOT/android/app/src/main/res" -o "$TASK_BUILD/resources.zip"
"$TASK_BT/aapt2" link -I "$TASK_PLATFORM" --manifest "$TASK_ROOT/android/app/src/main/AndroidManifest.xml" -A "$TASK_ROOT/android/app/src/main/assets" "$TASK_BUILD/resources.zip" -o "$TASK_BUILD/unsigned.apk"
javac -source 8 -target 8 -classpath "$TASK_PLATFORM" -d "$TASK_BUILD/classes" "$TASK_ROOT/android/app/src/main/java/com/kukirin/archive/MainActivity.java"
"$TASK_BT/d8" --lib "$TASK_PLATFORM" --min-api 26 --output "$TASK_BUILD/dex" "$TASK_BUILD/classes/com/kukirin/archive/"*.class
python3 - "$TASK_BUILD" <<'PY'
import sys,zipfile,pathlib
b=pathlib.Path(sys.argv[1])
with zipfile.ZipFile(b/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:z.write(b/'dex/classes.dex','classes.dex')
PY
"$TASK_BT/zipalign" -f -p 4 "$TASK_BUILD/unsigned.apk" "$TASK_BUILD/aligned.apk"
TASK_KEY="$TASK_SDK/archive-release.jks"
if [ ! -f "$TASK_KEY" ]; then keytool -genkeypair -keystore "$TASK_KEY" -alias kukirin -keyalg RSA -keysize 2048 -validity 10000 -storepass archive-local-build -keypass archive-local-build -dname 'CN=KuKirin Archive Independent, O=Local Development, C=TR'; fi
"$TASK_BT/apksigner" sign --ks "$TASK_KEY" --ks-pass pass:archive-local-build --key-pass pass:archive-local-build --out "$TASK_ROOT/outputs/KuKirin-Arsiv.apk" "$TASK_BUILD/aligned.apk"
"$TASK_BT/apksigner" verify --verbose "$TASK_ROOT/outputs/KuKirin-Arsiv.apk"
echo "APK hazır: $TASK_ROOT/outputs/KuKirin-Arsiv.apk"
