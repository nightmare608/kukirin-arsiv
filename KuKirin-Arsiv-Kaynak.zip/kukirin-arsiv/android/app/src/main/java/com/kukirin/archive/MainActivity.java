package com.kukirin.archive;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;
public final class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  getWindow().setStatusBarColor(0xff101212);getWindow().setNavigationBarColor(0xff141717);
  web=new WebView(this);web.setBackgroundColor(0xff101212);setContentView(web);
  web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowContentAccess(false);
  web.getSettings().setAllowFileAccessFromFileURLs(false);web.getSettings().setAllowUniversalAccessFromFileURLs(false);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest r){return openExternal(r.getUrl());}
   @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return openExternal(Uri.parse(url));}
  });web.loadUrl("file:///android_asset/index.html");
 }
 private boolean openExternal(Uri uri){
  if("https".equals(uri.getScheme())){try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){}return true;}
  return !uri.toString().startsWith("file:///android_asset/");
 }
 @Override public void onBackPressed(){web.evaluateJavascript("window.appBack ? window.appBack() : false",result->{if(!"true".equals(result))finish();});}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
